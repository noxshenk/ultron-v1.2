/* eslint-disable @typescript-eslint/no-explicit-any */
export const speechRecognitionSupported = () =>
  typeof window !== "undefined" && ("SpeechRecognition" in window || "webkitSpeechRecognition" in window);

export const ttsSupported = () => typeof window !== "undefined" && "speechSynthesis" in window;

export function createRecognizer(handlers: {
  onResult: (text: string) => void;
  onInterim?: (text: string) => void;
  onEnd: () => void;
  onError: (msg: string) => void;
}) {
  const Rec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
  const rec = new Rec();
  rec.lang = navigator.language || "en-US";
  rec.continuous = false;
  rec.interimResults = true;
  let finalText = "";
  rec.onresult = (e: any) => {
    let interim = "";
    for (let i = e.resultIndex; i < e.results.length; i++) {
      const r = e.results[i];
      if (r.isFinal) finalText += r[0].transcript;
      else interim += r[0].transcript;
    }
    if (interim) handlers.onInterim?.(finalText + interim);
  };
  rec.onerror = (e: any) => {
    const map: Record<string, string> = {
      "not-allowed": "Microphone permission was denied.",
      "service-not-allowed": "Speech service is not allowed in this browser context.",
      "no-speech": "No speech detected.",
      "audio-capture": "No microphone found.",
      network: "Speech recognition needs a network connection in this browser.",
    };
    handlers.onError(map[e.error] || `Speech recognition error: ${e.error}`);
  };
  rec.onend = () => {
    if (finalText.trim()) handlers.onResult(finalText.trim());
    handlers.onEnd();
  };
  return rec as { start: () => void; stop: () => void; abort: () => void };
}

export function cleanForSpeech(text: string) {
  return text
    .replace(/```[\s\S]*?```/g, " code block ")
    .replace(/[*_`#>~]/g, "")
    .replace(/\[(.*?)\]\(.*?\)/g, "$1")
    .trim();
}

export function speak(text: string, opts: { pitch: number; rate: number; volume: number; voiceURI?: string; onEnd?: () => void }) {
  if (!ttsSupported()) return;
  const synth = window.speechSynthesis;
  synth.cancel();
  const u = new SpeechSynthesisUtterance(cleanForSpeech(text));
  u.pitch = opts.pitch;
  u.rate = opts.rate;
  u.volume = Math.min(1, Math.max(0, opts.volume));
  if (opts.voiceURI) {
    const v = synth.getVoices().find((x) => x.voiceURI === opts.voiceURI);
    if (v) u.voice = v;
  }
  u.onend = () => opts.onEnd?.();
  u.onerror = () => opts.onEnd?.();
  synth.speak(u);
}

export function stopSpeaking() {
  if (ttsSupported()) window.speechSynthesis.cancel();
}

let audioCtx: AudioContext | null = null;
export function chirp(freq = 600, volume = 85, type: OscillatorType = "sine", duration = 0.08) {
  try {
    const AC = window.AudioContext || (window as any).webkitAudioContext;
    if (!audioCtx) audioCtx = new AC();
    if (audioCtx.state === "suspended") audioCtx.resume();
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
    gain.gain.setValueAtTime((volume / 100) * 0.15, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start();
    osc.stop(audioCtx.currentTime + duration);
  } catch {
    /* ignore */
  }
}
