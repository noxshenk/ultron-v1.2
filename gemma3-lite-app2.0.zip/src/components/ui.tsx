import type { CSSProperties, ReactNode } from "react";

export function Icon({ name, className = "", style }: { name: string; className?: string; style?: CSSProperties }) {
  return (
    <span className={`material-symbols-outlined ${className}`} style={style}>
      {name}
    </span>
  );
}

export const modalCardStyle: CSSProperties = {
  background: "linear-gradient(155deg, rgb(16, 18, 24) 0%, rgb(9, 10, 14) 100%)",
};

export function Overlay({
  open,
  onClose,
  children,
  position = "top",
  z = 50,
}: {
  open: boolean;
  onClose: () => void;
  children: ReactNode;
  position?: "top" | "bottom";
  z?: number;
}) {
  return (
    <div
      className={`modal-overlay ${open ? "active" : ""} fixed inset-0 flex justify-center bg-black/80 backdrop-blur-md ${
        position === "top" ? "items-start pt-20 sm:pt-24 px-3.5" : "items-end sm:items-center p-0 sm:p-4"
      }`}
      style={{ zIndex: z }}
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      aria-hidden={!open}
    >
      {children}
    </div>
  );
}

export function ModalHeader({
  icon,
  title,
  subtitle,
  onClose,
}: {
  icon: string;
  title: string;
  subtitle?: string;
  onClose: () => void;
}) {
  return (
    <div className="flex items-center justify-between pb-3 border-b border-white/5">
      <div className="flex items-center gap-2.5 min-w-0">
        <div
          className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0"
          style={{ background: "rgba(var(--theme-accent-rgb), 0.12)", border: "1px solid var(--theme-accent)" }}
        >
          <Icon name={icon} className="dyn-accent-text text-[17px]" />
        </div>
        <div className="min-w-0">
          <h2 className="font-mono text-xs uppercase tracking-widest text-white font-bold truncate">{title}</h2>
          {subtitle && <span className="font-mono text-[9px] text-[#7A91B8]">{subtitle}</span>}
        </div>
      </div>
      <button
        type="button"
        onClick={onClose}
        className="w-7 h-7 rounded-lg vantix-btn flex items-center justify-center text-[#7A91B8] hover:text-white"
        title="Close"
      >
        <Icon name="close" className="text-[16px]" />
      </button>
    </div>
  );
}
