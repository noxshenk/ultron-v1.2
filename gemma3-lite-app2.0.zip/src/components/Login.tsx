import { useState } from "react";
import { Icon } from "./ui";
import type { Profile } from "../lib/store";

export default function Login({ onLogin }: { onLogin: (p: Profile) => void }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);

  const nameFrom = (e: string) =>
    e
      .split("@")[0]
      .replace(/[._-]+/g, " ")
      .replace(/\b\w/g, (c) => c.toUpperCase()) || "Operator";

  const submit = (provider: Profile["provider"], mail?: string) => {
    const e = (mail ?? email).trim() || "operator@local.device";
    onLogin({ name: nameFrom(e), email: e, provider, createdAt: Date.now() });
  };

  return (
    <div className="fixed inset-0 z-[70] grid place-items-center p-5 overflow-y-auto bg-[#0a0a0f] text-white">
      <main className="login-form-wrapper" aria-label="Login">
        <div className="flex items-center justify-center gap-2 mb-2">
          <Icon name="terminal" className="dyn-accent-text text-[28px]" />
          <span className="font-mono font-bold tracking-[0.25em] text-white text-[16px] uppercase dyn-accent-glow">
            ULTRON // GATEWAY
          </span>
        </div>
        <h1 className="text-[1.85rem] font-bold text-center mb-2">Join Instantly</h1>
        <p className="text-center text-[0.85rem] text-slate-400 mb-6">
          Create a local profile to activate your private, in-browser AI workstation
        </p>

        <div className="flex gap-4 mb-6">
          <button type="button" className="social-btn" onClick={() => submit("google", "operator@gmail.local")} aria-label="Continue with Google">
            <svg width="22" height="22" viewBox="0 0 48 48">
              <path d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" fill="#EA4335" />
              <path d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" fill="#4285F4" />
              <path d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" fill="#FBBC05" />
              <path d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" fill="#34A853" />
            </svg>
          </button>
          <button type="button" className="social-btn" onClick={() => submit("github", "operator@github.local")} aria-label="Continue with GitHub">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="#fff">
              <path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z" />
            </svg>
          </button>
        </div>

        <div className="form-divider">
          <span>OR USE EMAIL</span>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            submit("email");
          }}
        >
          <div className="flex flex-col gap-2 mb-5">
            <label className="text-[0.86rem] font-semibold text-slate-400" htmlFor="loginEmail">
              Email Address
            </label>
            <input
              id="loginEmail"
              className="form-input"
              type="email"
              autoComplete="email"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="flex flex-col gap-2 mb-5">
            <label className="text-[0.86rem] font-semibold text-slate-400" htmlFor="loginPassword">
              Passphrase
            </label>
            <div className="relative flex items-center">
              <input
                id="loginPassword"
                className="form-input"
                style={{ paddingRight: 50 }}
                type={show ? "text" : "password"}
                autoComplete="current-password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={4}
              />
              <button
                type="button"
                aria-label="Toggle passphrase visibility"
                onClick={() => setShow((s) => !s)}
                className="absolute right-2 w-9 h-9 rounded-[10px] flex items-center justify-center text-slate-400 border border-white/10 bg-[#101015]"
              >
                <Icon name={show ? "visibility_off" : "visibility"} className="text-[18px]" />
              </button>
            </div>
          </div>
          <button className="c-btn-primary" type="submit">
            Authenticate &amp; Launch Workstation
          </button>
        </form>
        <p className="mt-5 text-center text-[11px] leading-relaxed text-slate-500">
          <Icon name="lock" className="text-[12px] align-middle mr-1" />
          No server involved: your profile, chats and the AI model all stay on this device.
        </p>
      </main>
    </div>
  );
}
