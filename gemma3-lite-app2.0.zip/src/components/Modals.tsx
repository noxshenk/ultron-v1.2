import { useMemo, useState } from "react";
import { Icon, ModalHeader, Overlay, modalCardStyle } from "./ui";
import { MODEL_NAME, MODEL_SIZE_MB, type Device } from "../lib/modelClient";
import { PERSONAS, timeAgo, fmtMB, type Persona, type Profile, type Session, type Settings } from "../lib/store";

/* ------------------------------------------------------------------ */
/* Model provisioning                                                  */
/* ------------------------------------------------------------------ */
export interface ModelState {
  phase: "checking" | "idle" | "downloading" | "loading" | "ready" | "error";
  device: Device;
  cached: boolean;
  loaded: number;
  total: number;
  bandwidth: number; // bytes / sec
  eta: number | null;
  status: string;
  error?: string;
}

export function SetupModal(props: {
  open: boolean;
  onClose: () => void;
  model: ModelState;
  asr: boolean;
  tts: boolean;
  onDownload: () => void;
  onDelete: () => void;
}) {
  const { model, open, onClose } = props;
  const pct = model.total ? Math.min(100, Math.floor((model.loaded / model.total) * 100)) : 0;
  const sizeMB = MODEL_SIZE_MB[model.device];
  const busy = model.phase === "downloading" || model.phase === "loading";

  const label =
    model.phase === "checking"
      ? "CHECKING DEVICE…"
      : model.phase === "idle"
        ? model.cached
          ? "LOAD MODEL FROM CACHE"
          : `DOWNLOAD MODEL (~${Math.round(sizeMB)} MB)`
        : model.phase === "downloading"
          ? `DOWNLOADING WEIGHTS (${pct}%)`
          : model.phase === "loading"
            ? "INITIALIZING RUNTIME…"
            : model.phase === "ready"
              ? "LAUNCH WORKSTATION"
              : "RETRY DOWNLOAD";

  const click = () => {
    if (model.phase === "ready") onClose();
    else if (model.phase === "idle" || model.phase === "error") props.onDownload();
  };

  return (
    <Overlay open={open} onClose={onClose} z={55}>
      <div className="modal-card vantix-panel w-full max-w-lg max-h-[85vh] overflow-y-auto p-3.5 space-y-3 rounded-2xl border" style={modalCardStyle}>
        <ModalHeader icon="memory" title="Model Provisioning" subtitle="Runs 100% locally in your browser" onClose={onClose} />

        <div className="p-3 rounded-xl space-y-2.5" style={{ background: "linear-gradient(160deg, rgb(9, 12, 18) 0%, rgb(5, 7, 11) 100%)", border: "1px solid rgba(var(--theme-accent-rgb), 0.35)" }}>
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0" style={{ background: "rgba(var(--theme-accent-rgb), 0.12)", border: "1px solid rgba(var(--theme-accent-rgb),0.4)" }}>
                <Icon name="auto_awesome" className="dyn-accent-text text-[18px]" />
              </div>
              <div className="flex flex-col min-w-0">
                <span className="font-mono text-[12px] text-white font-bold tracking-wide truncate">{MODEL_NAME}</span>
                <span className="font-mono text-[8.5px] text-[#7A91B8] tracking-wide">
                  LITERT INT4 • WEBGPU ACCELERATED • BROWSER CACHE
                </span>
              </div>
            </div>
            {model.phase === "downloading" && (
              <div className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-black/60 border border-white/10 shrink-0">
                <div className="flex items-end gap-[2px] h-3 w-3.5">
                  <span className="w-[2px] h-1.5 dyn-accent-bg rounded-full net-blip-bar" style={{ animationDelay: "0.1s" }} />
                  <span className="w-[2px] h-2.5 dyn-accent-bg rounded-full net-blip-bar" style={{ animationDelay: "0.3s" }} />
                  <span className="w-[2px] h-2 dyn-accent-bg rounded-full net-blip-bar" style={{ animationDelay: "0.15s" }} />
                  <span className="w-[2px] h-3 bg-white rounded-full net-blip-bar" style={{ animationDelay: "0.4s" }} />
                </div>
                <span className="font-mono text-[9px] font-bold dyn-accent-text">{(model.bandwidth / 1e6).toFixed(1)} MB/s</span>
              </div>
            )}
            {model.phase === "ready" && (
              <div className="flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-400/40 shrink-0 font-mono text-[9px] font-bold text-emerald-400">
                <Icon name="check_circle" className="text-[12px]" /> READY
              </div>
            )}
          </div>

          <div className="space-y-1 pt-0.5">
            <div className="flex items-center justify-between text-[10px] font-mono">
              <div className="flex items-center gap-1.5 min-w-0">
                {busy && <Icon name="progress_activity" className="text-[13px] dyn-accent-text animate-spin" />}
                <span className="text-[#9db2d6] text-[9px] truncate">{model.status || (model.phase === "ready" ? "Model loaded in memory" : "Waiting for your go-ahead")}</span>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <span className="text-[#7A91B8] text-[9px]">
                  {fmtMB(model.loaded)} MB / {fmtMB(model.total || sizeMB * 1e6)} MB
                </span>
                <span className="font-bold dyn-accent-text text-xs">{model.phase === "ready" ? 100 : pct}%</span>
              </div>
            </div>
            <div className="w-full h-1.5 rounded-full bg-black/90 overflow-hidden relative border border-white/10">
              <div
                className="h-full rounded-full dyn-accent-bg transition-all duration-300 ease-out relative overflow-hidden"
                style={{ width: `${model.phase === "ready" ? 100 : model.phase === "loading" && !model.loaded ? 100 : pct}%`, boxShadow: "0 0 10px var(--theme-accent)" }}
              >
                {busy && <div className="laser-shimmer" />}
              </div>
            </div>
            <div className="flex items-center justify-between text-[8.5px] font-mono text-[#7A91B8] pt-0.5">
              <span>
                ETA: <strong className="dyn-light-text">{model.phase === "downloading" && model.eta != null ? `~${model.eta}s` : "—"}</strong>
              </span>
              <span>{model.cached || model.phase === "ready" ? "CACHED ON DEVICE" : "NOT CACHED YET"}</span>
            </div>
          </div>

          {model.phase === "error" && (
            <div className="p-2 rounded-lg bg-red-500/10 border border-red-500/40 font-mono text-[10px] text-red-300 break-words">
              <Icon name="error" className="text-[13px] align-middle mr-1" />
              {model.error}
            </div>
          )}
        </div>

        <div className="p-2 rounded-xl bg-[#080b10] border border-white/5 flex items-center justify-between font-mono text-[9px]">
          <div className="flex items-center gap-1.5 text-[#7A91B8] uppercase font-semibold">
            <Icon name="hub" className="text-[14px] dyn-accent-text" />
            <span>RUNTIME:</span>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1">
              <span className="text-[#7A91B8]">ASR</span>
              <span className={props.asr ? "text-emerald-400 font-bold" : "text-red-400 font-bold"}>{props.asr ? "ON" : "N/A"}</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="text-[#7A91B8]">TTS</span>
              <span className={props.tts ? "text-emerald-400 font-bold" : "text-red-400 font-bold"}>{props.tts ? "ON" : "N/A"}</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="text-[#7A91B8]">WEBGPU</span>
              <span className="text-emerald-400 font-bold">REQUIRED</span>
            </div>
          </div>
        </div>

        <p className="font-mono text-[9.5px] leading-relaxed text-[#7A91B8]">
          Gemma3-1B-IT (LiteRT int4, ~700 MB) streams from Hugging Face straight into your browser's Cache Storage — a one-time download. After that the assistant works offline and nothing you type ever leaves your device. This lite build is text-only (no image input) and needs a WebGPU-capable browser: Chrome/Edge 121+ or Safari 26+.
        </p>

        <div className="flex items-center gap-2 pt-0.5">
          <button
            type="button"
            onClick={click}
            disabled={busy || model.phase === "checking"}
            className="flex-1 py-2.5 px-3 rounded-xl font-mono text-[11px] font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all border text-white active:scale-95 disabled:opacity-80"
            style={{ background: "linear-gradient(135deg, var(--theme-secondary), var(--theme-accent))", boxShadow: "0 4px 14px var(--theme-glow)", borderColor: "rgba(255,255,255,0.35)" }}
          >
            <Icon name={busy || model.phase === "checking" ? "sync" : model.phase === "ready" ? "rocket_launch" : "download"} className={`text-[15px] ${busy || model.phase === "checking" ? "animate-spin" : ""}`} />
            <span>{label}</span>
          </button>
          {(model.cached || model.phase === "ready") && !busy && (
            <button type="button" onClick={props.onDelete} className="vantix-btn px-3 py-2.5 rounded-xl font-mono text-[10px] text-[#ff334b] uppercase tracking-wider font-semibold" title="Delete the downloaded model from this browser">
              <Icon name="delete" className="text-[15px] align-middle" />
            </button>
          )}
        </div>
      </div>
    </Overlay>
  );
}

/* ------------------------------------------------------------------ */
/* Settings                                                            */
/* ------------------------------------------------------------------ */
export function SettingsModal(props: {
  open: boolean;
  onClose: () => void;
  settings: Settings;
  voices: SpeechSynthesisVoice[];
  onChange: (patch: Partial<Settings>) => void;
  onTestVoice: () => void;
}) {
  const { settings: s } = props;
  return (
    <Overlay open={props.open} onClose={props.onClose}>
      <div className="modal-card vantix-panel w-full max-w-md max-h-[82vh] overflow-y-auto p-4 space-y-4 rounded-2xl border" style={modalCardStyle}>
        <ModalHeader icon="tune" title="Tactical Controls & Config" onClose={props.onClose} />
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="font-mono text-[10px] text-[#7A91B8] uppercase tracking-wider font-semibold">AI Personality Architecture</span>
            <span className="font-mono text-[9px] dyn-accent-text tracking-wide font-bold">ACTIVE: {PERSONAS[s.persona].label}</span>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {(["ultron", "jarvis", "friday"] as Persona[]).map((p) => {
              const dot = p === "ultron" ? "#ff2238" : p === "jarvis" ? "#00d2ff" : "#ffcc00";
              const bg = p === "ultron" ? "linear-gradient(145deg, rgb(24, 17, 19), rgb(13, 8, 9))" : p === "jarvis" ? "linear-gradient(145deg, rgb(14, 22, 36), rgb(8, 13, 22))" : "linear-gradient(145deg, rgb(26, 23, 13), rgb(14, 12, 6))";
              const active = s.persona === p;
              return (
                <button
                  key={p}
                  type="button"
                  onClick={() => props.onChange({ persona: p })}
                  className="flex flex-col items-start p-2.5 rounded-xl border transition-all text-left group"
                  style={{ background: bg, borderColor: active ? "var(--theme-accent)" : "rgba(255,255,255,0.08)", boxShadow: active ? "0 0 14px var(--theme-glow)" : "none" }}
                >
                  <div className="flex items-center justify-between w-full">
                    <span className="font-mono text-[11px] font-bold text-white tracking-wider">{PERSONAS[p].label}</span>
                    <span className="w-2 h-2 rounded-full" style={{ background: dot, opacity: active ? 1 : 0.4, boxShadow: active ? `0 0 6px ${dot}` : "none" }} />
                  </div>
                  <span className="text-[9px] text-[#9db2d6] mt-1 leading-tight">{PERSONAS[p].sub}</span>
                </button>
              );
            })}
          </div>
          <p className="font-mono text-[9px] text-[#7A91B8]">The persona changes theme, voice pitch and the system instruction the model follows.</p>
        </div>

        <div className="vantix-inset p-3 space-y-2 rounded-xl" style={{ background: "#090b10" }}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <Icon name="graphic_eq" className="text-[15px] dyn-accent-text" />
              <span className="font-mono text-[10px] text-white tracking-wider uppercase font-semibold">Synthesis Volume</span>
            </div>
            <span className="font-mono text-[10px] dyn-light-text font-bold">
              {s.volume >= 70 ? "HIGH" : s.volume >= 40 ? "NORMAL" : "WHISPER"} // {s.volume}%
            </span>
          </div>
          <input type="range" className="w-full tactical-slider cursor-pointer" min={10} max={100} value={s.volume} onChange={(e) => props.onChange({ volume: +e.target.value })} />
        </div>

        <div className="vantix-inset p-3 space-y-2 rounded-xl" style={{ background: "#090b10" }}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <Icon name="record_voice_over" className="text-[15px] dyn-accent-text" />
              <span className="font-mono text-[10px] text-white tracking-wider uppercase font-semibold">Voice</span>
            </div>
            <button type="button" onClick={props.onTestVoice} className="vantix-btn px-2 py-1 font-mono text-[9px] text-white uppercase tracking-wider">
              Test
            </button>
          </div>
          <select
            value={s.voiceURI}
            onChange={(e) => props.onChange({ voiceURI: e.target.value })}
            className="w-full bg-[#05070b] border border-white/10 rounded-lg px-2 py-2 font-mono text-[11px] text-white outline-none"
          >
            <option value="">System default</option>
            {props.voices.map((v) => (
              <option key={v.voiceURI} value={v.voiceURI}>
                {v.name} ({v.lang})
              </option>
            ))}
          </select>
        </div>

        <button type="button" onClick={props.onClose} className="w-full py-2.5 rounded-xl font-mono text-xs uppercase tracking-widest font-bold text-white active:scale-95 grad-btn">
          Done
        </button>
      </div>
    </Overlay>
  );
}

/* ------------------------------------------------------------------ */
/* Profile                                                             */
/* ------------------------------------------------------------------ */
export function ProfileModal(props: { open: boolean; onClose: () => void; profile: Profile | null; onSignOut: () => void; storageText: string }) {
  const p = props.profile;
  return (
    <Overlay open={props.open} onClose={props.onClose}>
      <div className="modal-card vantix-panel w-full max-w-md p-4 space-y-4 rounded-2xl border" style={modalCardStyle}>
        <ModalHeader icon="person" title="Profile" onClose={props.onClose} />
        <div className="vantix-inset p-3.5 flex items-center gap-3.5 rounded-xl" style={{ background: "#090b10" }}>
          <div className="w-14 h-14 rounded-xl p-[2px] shrink-0" style={{ background: "linear-gradient(135deg, var(--theme-secondary), var(--theme-accent))" }}>
            <div className="w-full h-full rounded-xl bg-[#030B1E] flex items-center justify-center">
              <Icon name="shield_person" className="dyn-accent-text text-[30px]" />
            </div>
          </div>
          <div className="flex flex-col min-w-0">
            <span className="font-mono text-sm text-white font-bold tracking-wider truncate uppercase">{p?.name}</span>
            <span className="font-mono text-[10.5px] text-[#7A91B8] truncate mt-0.5">{p?.email}</span>
            <span className="inline-flex items-center gap-1.5 mt-1.5 px-2 py-0.5 rounded bg-black/60 border border-white/5 w-fit font-mono text-[9px] dyn-accent-text uppercase">
              {p?.provider} · local profile
            </span>
          </div>
        </div>
        <p className="font-mono text-[10px] text-[#7A91B8] leading-relaxed">{props.storageText}</p>
        <button type="button" onClick={props.onSignOut} className="w-full py-2.5 px-3 rounded-xl font-mono text-[11px] font-bold uppercase tracking-wider text-[#ff334b] border border-[#ff334b]/40 flex items-center justify-center gap-2 hover:bg-[#ff334b]/10 active:scale-95 transition-all">
          <Icon name="power_settings_new" className="text-[16px]" />
          <span>Sign out / lock workstation</span>
        </button>
      </div>
    </Overlay>
  );
}

/* ------------------------------------------------------------------ */
/* Chat history                                                        */
/* ------------------------------------------------------------------ */
export function HistoryModal(props: {
  open: boolean;
  onClose: () => void;
  sessions: Session[];
  activeId: string;
  onOpen: (id: string) => void;
  onDelete: (id: string) => void;
  onNew: () => void;
  onClear: () => void;
}) {
  const [q, setQ] = useState("");
  const list = useMemo(() => {
    const t = q.toLowerCase().trim();
    return [...props.sessions]
      .sort((a, b) => b.updatedAt - a.updatedAt)
      .filter((s) => !t || s.title.toLowerCase().includes(t) || s.messages.some((m) => m.text.toLowerCase().includes(t)));
  }, [props.sessions, q]);

  return (
    <Overlay open={props.open} onClose={props.onClose} position="bottom">
      <div className="modal-card vantix-panel w-full max-w-lg max-h-[85vh] flex flex-col rounded-t-2xl sm:rounded-2xl border overflow-hidden" style={modalCardStyle}>
        <div className="p-3.5">
          <ModalHeader icon="forum" title="Archived Chat Sessions" onClose={props.onClose} />
        </div>
        <div className="px-3.5 pb-3.5 space-y-3 overflow-y-auto flex-1">
          <div className="vantix-inset flex items-center gap-2 px-3 py-2 rounded-xl" style={{ background: "#090b10" }}>
            <Icon name="search" className="text-[#7A91B8] text-[18px]" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search past sessions or directives..." className="bg-transparent border-0 outline-none font-mono text-xs text-white placeholder-[#5A7096] w-full" />
          </div>
          <div className="space-y-2">
            {list.length === 0 && <div className="p-4 text-center font-mono text-[11px] text-[#7A91B8]">{props.sessions.length ? "No sessions match your search." : "No saved sessions yet."}</div>}
            {list.map((s) => {
              const active = s.id === props.activeId;
              const last = s.messages[s.messages.length - 1];
              return (
                <div
                  key={s.id}
                  onClick={() => props.onOpen(s.id)}
                  className="vantix-inset p-3 rounded-xl flex items-center justify-between gap-2 group hover:border-[var(--theme-accent)] transition-all cursor-pointer"
                  style={active ? { borderLeft: "2px solid var(--theme-accent)" } : undefined}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border border-white/10" style={{ background: "rgba(var(--theme-accent-rgb), 0.1)" }}>
                      <Icon name="chat" className="dyn-accent-text text-[18px]" />
                    </div>
                    <div className="flex flex-col min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-[11px] font-bold text-white truncate">{s.title}</span>
                        {active && <span className="font-mono text-[8.5px] px-1.5 py-0.5 rounded dyn-accent-bg text-black font-bold uppercase shrink-0">Active</span>}
                      </div>
                      <span className="font-mono text-[9px] text-[#7A91B8] truncate mt-0.5">
                        {s.messages.length} msgs • {timeAgo(s.updatedAt)}
                        {last ? ` • ${last.text.slice(0, 50)}` : ""}
                      </span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      props.onDelete(s.id);
                    }}
                    className="w-7 h-7 rounded-lg vantix-btn flex items-center justify-center text-[#7A91B8] hover:text-[#ff334b] shrink-0"
                    title="Delete session"
                  >
                    <Icon name="delete" className="text-[15px]" />
                  </button>
                </div>
              );
            })}
          </div>
        </div>
        <div className="p-3.5 pt-0 flex gap-2">
          <button type="button" onClick={props.onNew} className="flex-1 py-2 rounded-xl vantix-btn font-mono text-[11px] font-bold uppercase tracking-wider text-white active:scale-95 flex items-center justify-center gap-1.5">
            <Icon name="add" className="text-[16px] dyn-accent-text" />
            <span>New Session</span>
          </button>
          <button type="button" onClick={props.onClear} className="vantix-btn px-3 py-2 rounded-xl font-mono text-[10px] text-[#ff334b] uppercase tracking-wider font-semibold active:scale-95">
            Clear All
          </button>
        </div>
      </div>
    </Overlay>
  );
}

/* ------------------------------------------------------------------ */
/* Context tuning                                                      */
/* ------------------------------------------------------------------ */
export function ContextModal(props: { open: boolean; onClose: () => void; settings: Settings; onChange: (patch: Partial<Settings>) => void }) {
  const s = props.settings;
  const desc = s.temperature < 0.2 ? "GREEDY // DETERMINISTIC" : s.temperature < 0.5 ? "PRECISE" : s.temperature < 0.8 ? "BALANCED" : "CREATIVE";
  return (
    <Overlay open={props.open} onClose={props.onClose} position="bottom">
      <div className="modal-card vantix-panel w-full max-w-md max-h-[85vh] flex flex-col rounded-t-2xl sm:rounded-2xl border overflow-hidden" style={modalCardStyle}>
        <div className="p-3.5">
          <ModalHeader icon="data_object" title="Context Window & Inference" subtitle="Applied to every next generation" onClose={props.onClose} />
        </div>
        <div className="px-4 pb-4 space-y-4 overflow-y-auto flex-1">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-mono text-[10px] text-[#7A91B8] uppercase tracking-wider font-semibold">Conversation memory budget</span>
              <span className="font-mono text-[10px] text-blue-400 font-bold">{s.contextTokens} TOKENS</span>
            </div>
            <input type="range" className="w-full tactical-slider cursor-pointer" min={1024} max={8192} step={512} value={s.contextTokens} onChange={(e) => props.onChange({ contextTokens: +e.target.value })} />
            <div className="grid grid-cols-4 gap-1.5 pt-1">
              {[1024, 2048, 4096, 8192].map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => props.onChange({ contextTokens: t })}
                  className="py-1.5 rounded-lg border font-mono text-[10px] text-white active:scale-95 transition-all"
                  style={s.contextTokens === t ? { background: "rgba(var(--theme-accent-rgb), 0.2)", borderColor: "var(--theme-accent)", boxShadow: "0 0 10px var(--theme-glow)" } : { background: "rgb(10, 13, 19)", borderColor: "rgba(255,255,255,0.08)" }}
                >
                  {t / 1024}K
                </button>
              ))}
            </div>
            <p className="font-mono text-[9px] text-[#7A91B8]">Older messages beyond this budget are dropped from the prompt (the visible chat is kept).</p>
          </div>

          <div className="vantix-inset p-3 space-y-2 rounded-xl" style={{ background: "#090b10" }}>
            <div className="flex items-center justify-between">
              <span className="font-mono text-[10px] text-white tracking-wider uppercase font-semibold">Max response length</span>
              <span className="font-mono text-[10px] dyn-light-text font-bold">{s.maxNewTokens} TOK</span>
            </div>
            <input type="range" className="w-full tactical-slider cursor-pointer" min={64} max={1024} step={32} value={s.maxNewTokens} onChange={(e) => props.onChange({ maxNewTokens: +e.target.value })} />
          </div>

          <div className="vantix-inset p-3 space-y-2 rounded-xl" style={{ background: "#090b10" }}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <Icon name="thermostat" className="text-[15px] dyn-accent-text" />
                <span className="font-mono text-[10px] text-white tracking-wider uppercase font-semibold">Sampling temperature</span>
              </div>
              <span className="font-mono text-[10px] dyn-light-text font-bold">
                {s.temperature.toFixed(2)} // {desc}
              </span>
            </div>
            <input type="range" className="w-full tactical-slider cursor-pointer" min={0.1} max={1} step={0.05} value={s.temperature} onChange={(e) => props.onChange({ temperature: +e.target.value })} />
          </div>

          <button type="button" onClick={props.onClose} className="w-full py-2.5 rounded-xl font-mono text-xs uppercase tracking-widest font-bold text-white active:scale-95 grad-btn">
            Apply Tuning
          </button>
        </div>
      </div>
    </Overlay>
  );
}
