import { useEffect, useRef } from "react";
import * as THREE from "three";

export type OrbMode = "idle" | "listening" | "thinking" | "speaking";

interface Props {
  accent: string;
  secondary: string;
  mode: OrbMode;
}

/* ------------------------------------------------------------------ */
/* GLSL: Ashima 3D simplex noise                                       */
/* ------------------------------------------------------------------ */
const NOISE_GLSL = /* glsl */ `
vec3 mod289(vec3 x){ return x - floor(x * (1.0/289.0)) * 289.0; }
vec4 mod289(vec4 x){ return x - floor(x * (1.0/289.0)) * 289.0; }
vec4 permute(vec4 x){ return mod289(((x*34.0)+1.0)*x); }
vec4 taylorInvSqrt(vec4 r){ return 1.79284291400159 - 0.85373472095314 * r; }
float snoise(vec3 v){
  const vec2 C = vec2(1.0/6.0, 1.0/3.0);
  const vec4 D = vec4(0.0, 0.5, 1.0, 2.0);
  vec3 i  = floor(v + dot(v, C.yyy));
  vec3 x0 = v - i + dot(i, C.xxx);
  vec3 g = step(x0.yzx, x0.xyz);
  vec3 l = 1.0 - g;
  vec3 i1 = min(g.xyz, l.zxy);
  vec3 i2 = max(g.xyz, l.zxy);
  vec3 x1 = x0 - i1 + C.xxx;
  vec3 x2 = x0 - i2 + C.yyy;
  vec3 x3 = x0 - D.yyy;
  i = mod289(i);
  vec4 p = permute(permute(permute(
             i.z + vec4(0.0, i1.z, i2.z, 1.0))
           + i.y + vec4(0.0, i1.y, i2.y, 1.0))
           + i.x + vec4(0.0, i1.x, i2.x, 1.0));
  float n_ = 0.142857142857;
  vec3 ns = n_ * D.wyz - D.xzx;
  vec4 j = p - 49.0 * floor(p * ns.z * ns.z);
  vec4 x_ = floor(j * ns.z);
  vec4 y_ = floor(j - 7.0 * x_);
  vec4 x = x_ * ns.x + ns.yyyy;
  vec4 y = y_ * ns.x + ns.yyyy;
  vec4 h = 1.0 - abs(x) - abs(y);
  vec4 b0 = vec4(x.xy, y.xy);
  vec4 b1 = vec4(x.zw, y.zw);
  vec4 s0 = floor(b0) * 2.0 + 1.0;
  vec4 s1 = floor(b1) * 2.0 + 1.0;
  vec4 sh = -step(h, vec4(0.0));
  vec4 a0 = b0.xzyw + s0.xzyw * sh.xxyy;
  vec4 a1 = b1.xzyw + s1.xzyw * sh.zzww;
  vec3 p0 = vec3(a0.xy, h.x);
  vec3 p1 = vec3(a0.zw, h.y);
  vec3 p2 = vec3(a1.xy, h.z);
  vec3 p3 = vec3(a1.zw, h.w);
  vec4 norm = taylorInvSqrt(vec4(dot(p0,p0), dot(p1,p1), dot(p2,p2), dot(p3,p3)));
  p0 *= norm.x; p1 *= norm.y; p2 *= norm.z; p3 *= norm.w;
  vec4 m = max(0.6 - vec4(dot(x0,x0), dot(x1,x1), dot(x2,x2), dot(x3,x3)), 0.0);
  m = m * m;
  return 42.0 * dot(m*m, vec4(dot(p0,x0), dot(p1,x1), dot(p2,x2), dot(p3,x3)));
}
`;

/* Blob surface: layered simplex displacement + recomputed normal-ish shading */
const BLOB_VERT = /* glsl */ `
uniform float uTime;
uniform float uAmp;
uniform float uFreq;
uniform float uSpeed;
varying vec3 vViewNormal;
varying vec3 vViewPos;
varying float vNoise;
${NOISE_GLSL}
void main() {
  float t = uTime * uSpeed;
  float n1 = snoise(position * uFreq + vec3(0.0, t * 0.7, t * 0.5));
  float n2 = snoise(position * uFreq * 2.1 - vec3(t * 0.9, 0.0, t * 0.6)) * 0.35;
  float n3 = snoise(position * uFreq * 4.3 + vec3(t * 1.4)) * 0.07;
  float disp = (n1 + n2 + n3) * uAmp;
  // broad rolling wave so speaking stays smooth, never spiky
  disp += sin(position.y * 1.8 + t * 2.2) * uAmp * 0.35;
  vec3 displaced = position + normal * disp;
  vNoise = n1 + n2 * 0.6;

  // approximate displaced normal by sampling neighbours on the sphere
  float eps = 0.08;
  vec3 tang = normalize(cross(normal, vec3(0.0, 1.0, 0.001)));
  vec3 bitang = normalize(cross(normal, tang));
  float nA = snoise((position + tang * eps) * uFreq + vec3(0.0, t * 0.7, t * 0.5)) + sin((position + tang * eps).y * 1.8 + t * 2.2) * 0.35;
  float nB = snoise((position + bitang * eps) * uFreq + vec3(0.0, t * 0.7, t * 0.5)) + sin((position + bitang * eps).y * 1.8 + t * 2.2) * 0.35;
  vec3 pA = position + tang * eps + normal * nA * uAmp;
  vec3 pB = position + bitang * eps + normal * nB * uAmp;
  vec3 nrm = normalize(cross(pA - displaced, pB - displaced));
  if (dot(nrm, normal) < 0.0) nrm = -nrm;

  vec4 mv = modelViewMatrix * vec4(displaced, 1.0);
  vViewPos = mv.xyz;
  vViewNormal = normalize(normalMatrix * nrm);
  gl_Position = projectionMatrix * mv;
}
`;

const BLOB_FRAG = /* glsl */ `
uniform vec3 uColorDeep;
uniform vec3 uColorAccent;
uniform vec3 uColorLight;
uniform float uGlow;
uniform float uPulse;
varying vec3 vViewNormal;
varying vec3 vViewPos;
varying float vNoise;
void main() {
  vec3 n = normalize(vViewNormal);
  vec3 v = normalize(-vViewPos);

  // ChatGPT-style soft gradient: light source upper-left, deep shade lower-right
  float lambert = clamp(dot(n, normalize(vec3(-0.45, 0.75, 0.65))), 0.0, 1.0);
  float fres = pow(1.0 - clamp(dot(n, v), 0.0, 1.0), 2.2);

  // base gradient driven by surface noise + vertical light falloff
  float mixN = smoothstep(-0.7, 0.9, vNoise);
  vec3 col = mix(uColorDeep, uColorAccent, mixN * 0.75 + lambert * 0.35);
  col = mix(col, uColorLight, pow(lambert, 1.6) * 0.55);

  // rim / inner glow
  col += uColorAccent * fres * uGlow;
  col += uColorLight * pow(lambert, 3.0) * 0.35 * uPulse;

  // gentle brightness pulse while speaking
  col *= 1.0 + uPulse * 0.18;

  gl_FragColor = vec4(col, 1.0);
}
`;

/* Soft radial halo rendered behind the blob */
const HALO_VERT = /* glsl */ `
varying vec2 vUv;
void main() {
  vUv = uv;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`;

const HALO_FRAG = /* glsl */ `
uniform vec3 uColor;
uniform float uOpacity;
uniform float uFalloff;
varying vec2 vUv;
void main() {
  float d = length(vUv - 0.5) * 2.0;
  float a = pow(max(1.0 - d, 0.0), uFalloff);
  gl_FragColor = vec4(uColor, a * uOpacity);
}
`;

/* Per-mode animation targets ------------------------------------------ */
interface OrbTuning {
  amp: number;      // surface undulation
  freq: number;     // noise frequency
  speed: number;    // flow speed of the noise field
  glow: number;     // rim glow strength
  pulse: number;    // brightness pulsation
  breathe: number;  // scale breathing
  spin: number;     // self rotation
  halo: number;     // halo opacity
  haloScale: number;
}

const TUNING: Record<OrbMode, OrbTuning> = {
  idle:      { amp: 0.028, freq: 1.0,  speed: 0.35, glow: 0.28, pulse: 0.0,  breathe: 0.014, spin: 0.05,  halo: 0.30, haloScale: 1.5 },
  listening: { amp: 0.06,  freq: 1.15, speed: 0.8,  glow: 0.45, pulse: 0.15, breathe: 0.025, spin: 0.10,  halo: 0.45, haloScale: 1.6 },
  thinking:  { amp: 0.10,  freq: 1.3,  speed: 1.6,  glow: 0.55, pulse: 0.25, breathe: 0.03,  spin: 0.22,  halo: 0.55, haloScale: 1.7 },
  speaking:  { amp: 0.155, freq: 1.15, speed: 2.0,  glow: 0.75, pulse: 0.6,  breathe: 0.045, spin: 0.12,  halo: 0.75, haloScale: 1.85 },
};

const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

export default function Orb({ accent, secondary, mode }: Props) {
  const host = useRef<HTMLDivElement>(null);
  const modeRef = useRef<OrbMode>(mode);
  const colorsRef = useRef({ accent, secondary });
  modeRef.current = mode;
  colorsRef.current = { accent, secondary };

  useEffect(() => {
    const el = host.current;
    if (!el) return;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setClearColor(0x000000, 0);
    renderer.domElement.style.width = "100%";
    renderer.domElement.style.height = "100%";
    renderer.domElement.style.touchAction = "none";
    el.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 100);
    camera.position.z = 5.6;

    const group = new THREE.Group();
    scene.add(group);

    /* ---------- ChatGPT-style blob ---------- */
    const blobGeo = new THREE.IcosahedronGeometry(1.6, 64);
    const blobUniforms = {
      uTime: { value: 0 },
      uAmp: { value: TUNING.idle.amp },
      uFreq: { value: TUNING.idle.freq },
      uSpeed: { value: TUNING.idle.speed },
      uGlow: { value: TUNING.idle.glow },
      uPulse: { value: 0 },
      uColorDeep: { value: new THREE.Color(secondary) },
      uColorAccent: { value: new THREE.Color(accent) },
      uColorLight: { value: new THREE.Color(accent).lerp(new THREE.Color(0xffffff), 0.65) },
    };
    const blobMat = new THREE.ShaderMaterial({
      vertexShader: BLOB_VERT,
      fragmentShader: BLOB_FRAG,
      uniforms: blobUniforms,
    });
    const blob = new THREE.Mesh(blobGeo, blobMat);
    group.add(blob);

    /* ---------- soft halo behind the blob ---------- */
    const haloUniforms = {
      uColor: { value: new THREE.Color(accent) },
      uOpacity: { value: TUNING.idle.halo },
      uFalloff: { value: 3.0 },
    };
    const haloMat = new THREE.ShaderMaterial({
      vertexShader: HALO_VERT,
      fragmentShader: HALO_FRAG,
      uniforms: haloUniforms,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });
    const halo = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), haloMat);
    scene.add(halo); // stays camera-facing, outside the drag-rotated group

    /* halo plane must always cover the frustum so its falloff reaches zero
       before the canvas edges — no visible rectangle regardless of aspect */
    const fitHalo = () => {
      const h = 2 * camera.position.z * Math.tan((camera.fov * Math.PI) / 360);
      const w = h * camera.aspect;
      halo.scale.setScalar(Math.sqrt(h * h + w * w) * 1.05);
    };

    /* ---------- drag to rotate ---------- */
    let dragging = false;
    let lastX = 0;
    let lastY = 0;
    let velX = 0;
    let velY = 0;
    const down = (e: PointerEvent) => {
      dragging = true;
      lastX = e.clientX;
      lastY = e.clientY;
      (e.target as Element).setPointerCapture?.(e.pointerId);
    };
    const move = (e: PointerEvent) => {
      if (!dragging) return;
      velY = (e.clientX - lastX) * 0.008;
      velX = (e.clientY - lastY) * 0.008;
      group.rotation.y += velY;
      group.rotation.x += velX;
      lastX = e.clientX;
      lastY = e.clientY;
    };
    const up = () => (dragging = false);
    renderer.domElement.addEventListener("pointerdown", down);
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);

    const resize = () => {
      const w = el.clientWidth || 300;
      const h = el.clientHeight || 300;
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      fitHalo();
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(el);

    /* ---------- animation loop ---------- */
    const cur: OrbTuning = { ...TUNING.idle };
    let pulsePhase = 0;
    const tmpAccent = new THREE.Color();
    const tmpSecondary = new THREE.Color();
    const tmpLight = new THREE.Color();
    const clock = new THREE.Clock();
    let raf = 0;

    const tick = () => {
      raf = requestAnimationFrame(tick);
      const dt = Math.min(clock.getDelta(), 0.05);
      const t = clock.elapsedTime;
      const target = TUNING[modeRef.current];

      // smooth transitions between modes
      const k = 1 - Math.pow(0.0025, dt); // frame-rate independent smoothing
      cur.amp = lerp(cur.amp, target.amp, k);
      cur.freq = lerp(cur.freq, target.freq, k);
      cur.speed = lerp(cur.speed, target.speed, k);
      cur.glow = lerp(cur.glow, target.glow, k);
      cur.pulse = lerp(cur.pulse, target.pulse, k);
      cur.breathe = lerp(cur.breathe, target.breathe, k);
      cur.spin = lerp(cur.spin, target.spin, k);
      cur.halo = lerp(cur.halo, target.halo, k);
      cur.haloScale = lerp(cur.haloScale, target.haloScale, k);

      // persona color cross-fade
      tmpAccent.set(colorsRef.current.accent);
      tmpSecondary.set(colorsRef.current.secondary);
      tmpLight.copy(tmpAccent).lerp(new THREE.Color(0xffffff), 0.65);
      blobUniforms.uColorAccent.value.lerp(tmpAccent, k);
      blobUniforms.uColorDeep.value.lerp(tmpSecondary, k);
      blobUniforms.uColorLight.value.lerp(tmpLight, k);
      haloUniforms.uColor.value.lerp(tmpAccent, k);

      // speaking pulse: organic double-wave, idle: slow breathing
      const m = modeRef.current;
      if (m === "speaking") {
        pulsePhase += dt * 9.5;
        blobUniforms.uPulse.value = (Math.sin(pulsePhase) * 0.5 + Math.sin(pulsePhase * 2.7 + 1.3) * 0.5) * 0.5 + 0.5;
      } else {
        pulsePhase += dt * 1.6;
        blobUniforms.uPulse.value = Math.sin(pulsePhase) * 0.5 + 0.5;
      }

      blobUniforms.uTime.value = t;
      blobUniforms.uAmp.value = cur.amp;
      blobUniforms.uFreq.value = cur.freq;
      blobUniforms.uSpeed.value = cur.speed;
      blobUniforms.uGlow.value = cur.glow;

      // breathing scale, amplified while speaking
      const breathe = 1 + Math.sin(t * (m === "speaking" ? 5.2 : 1.4)) * cur.breathe;
      blob.scale.setScalar(breathe);

      // halo reaction — always billboarded to the camera; wider falloff when active
      halo.quaternion.copy(camera.quaternion);
      haloUniforms.uOpacity.value = cur.halo * (0.75 + blobUniforms.uPulse.value * 0.35);
      haloUniforms.uFalloff.value = 3.6 - (cur.haloScale - 1.5) * 2.2; // idle tight → speaking wide

      // gentle self-rotation + inertia from drag
      if (!dragging) {
        group.rotation.y += (cur.spin + velY) * dt * 8;
        group.rotation.x += velX * dt * 8;
        velX *= 0.92;
        velY *= 0.92;
      }

      renderer.render(scene, camera);
    };
    tick();

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      renderer.domElement.removeEventListener("pointerdown", down);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      blobGeo.dispose();
      blobMat.dispose();
      halo.geometry.dispose();
      haloMat.dispose();
      renderer.dispose();
      renderer.domElement.remove();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return <div ref={host} className="absolute inset-0" />;
}
