---
name: Ultron Hardware
colors:
  surface: '#131316'
  surface-dim: '#131316'
  surface-bright: '#39393c'
  surface-container-lowest: '#0e0e11'
  surface-container-low: '#1c1b1e'
  surface-container: '#201f22'
  surface-container-high: '#2a2a2d'
  surface-container-highest: '#353438'
  on-surface: '#e5e1e5'
  on-surface-variant: '#cbc3d9'
  inverse-surface: '#e5e1e5'
  inverse-on-surface: '#313033'
  outline: '#958da2'
  outline-variant: '#4a4456'
  surface-tint: '#d0bcff'
  primary: '#d0bcff'
  on-primary: '#3b0092'
  primary-container: '#7c3cff'
  on-primary-container: '#f3e9ff'
  inverse-primary: '#6f28f2'
  secondary: '#ddb7ff'
  on-secondary: '#490080'
  secondary-container: '#6f00be'
  on-secondary-container: '#d6a9ff'
  tertiary: '#d2bbff'
  on-tertiary: '#3c177b'
  tertiary-container: '#7959ba'
  on-tertiary-container: '#f3e9ff'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e9ddff'
  primary-fixed-dim: '#d0bcff'
  on-primary-fixed: '#23005c'
  on-primary-fixed-variant: '#5500cb'
  secondary-fixed: '#f0dbff'
  secondary-fixed-dim: '#ddb7ff'
  on-secondary-fixed: '#2c0051'
  on-secondary-fixed-variant: '#6900b3'
  tertiary-fixed: '#eaddff'
  tertiary-fixed-dim: '#d2bbff'
  on-tertiary-fixed: '#25005a'
  on-tertiary-fixed-variant: '#533292'
  background: '#131316'
  on-background: '#e5e1e5'
  surface-variant: '#353438'
  surface-graphite: '#0B0B10'
  surface-graphite-raised: '#101017'
  foreground-off: '#F5F3EE'
  foreground-muted: '#9B9AA3'
  foreground-dim: '#63626C'
  hairline-line: rgba(245, 243, 238, 0.10)
  hairline-subtle: rgba(245, 243, 238, 0.055)
  accent-glow: rgba(124, 60, 255, 0.24)
  finish-obsidian: '#121317'
  finish-cloud: '#D7D4CD'
  finish-lilac: '#8C72A8'
  finish-moss: '#657B69'
typography:
  display-hero:
    fontFamily: Archivo Narrow
    fontSize: 5rem
    fontWeight: '800'
    lineHeight: 4.5rem
    letterSpacing: -0.045em
  display-hero-mobile:
    fontFamily: Archivo Narrow
    fontSize: 3rem
    fontWeight: '800'
    lineHeight: 2.75rem
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: Archivo Narrow
    fontSize: 3.5rem
    fontWeight: '800'
    lineHeight: 3.25rem
    letterSpacing: -0.035em
  headline-lg-mobile:
    fontFamily: Archivo Narrow
    fontSize: 2.25rem
    fontWeight: '800'
    lineHeight: 2.25rem
    letterSpacing: -0.025em
  headline-md:
    fontFamily: Archivo Narrow
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: 2.2rem
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Archivo Narrow
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.5rem
    letterSpacing: 0.02em
  body-lead:
    fontFamily: Archivo Narrow
    fontSize: 1.0625rem
    fontWeight: '400'
    lineHeight: 1.75rem
    letterSpacing: 0em
  body-default:
    fontFamily: Archivo Narrow
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.55rem
    letterSpacing: 0em
  body-sm:
    fontFamily: Archivo Narrow
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.35rem
    letterSpacing: 0em
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: 1rem
    letterSpacing: 0.20em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 0.6875rem
    fontWeight: '500'
    lineHeight: 0.875rem
    letterSpacing: 0.22em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 0.625rem
    fontWeight: '400'
    lineHeight: 0.75rem
    letterSpacing: 0.26em
  caption-micro:
    fontFamily: JetBrains Mono
    fontSize: 0.5625rem
    fontWeight: '400'
    lineHeight: 0.75rem
    letterSpacing: 0.24em
spacing:
  gutter: 1rem
  gutter-md: 1.5rem
  gutter-lg: 2rem
  margin: 1.25rem
  margin-md: 2.5rem
  margin-lg: 4.75rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system embodies an industrial cyberpunk aesthetic rooted in precision hardware engineering, high-fidelity instrumentation, and technical telemetry. Drawing inspiration from precision laboratory equipment, high-end avionics, and modernist synthesizer industrial design, the interface balances uncompromising utilitarian density with cinematic darkness.

The visual tone is cold, exact, and deliberately tactical. It avoids standard corporate softness in favor of micro-mechanical physical metaphors: hairline border grids, low-profile tactile controls, luminous phosphor indicators, and dense monospaced readouts. The emotional response should evoke military-grade reliability, cutting-edge machine intelligence, and the tactile satisfaction of bespoke pocket hardware.

## Colors

The color architecture is built around absolute dark-room black (`#050507`), preventing washed-out gray casts and creating a high-contrast viewport for phosphor emissions. Atmospheric depth is established using subtle shifts into graphite tiers (`#0B0B10` and `#101017`) rather than traditional drop shadows.

Chromatic energy is hyper-concentrated in the violet and electric purple spectrum. Primary actions and interactive fills leverage electric purple (`#7C3CFF`), with active highlights, focus rings, and status pips elevating to neon violet (`#A855F7`). Deep indigo (`#3B167A`) provides ambient floor lighting via subdued radial gradients. 

Text contrast is strictly tiered: primary foreground uses warm bone white (`#F5F3EE`), secondary guidance sits at neutral silver (`#9B9AA3`), and engineering captions or telemetry keys drop into dimmed slate (`#63626C`). Micro-dividers rely strictly on calibrated alpha layers of bone white (`10%` and `5.5%`) to emulate milled titanium bevels.

## Typography

The typography strategy hinges on a deliberate dual-engine pairing: condensed, aggressive structural sans (`Archivo Narrow`) for human messaging and titles, combined with a calibrated, industrial monospace (`JetBrains Mono`) for functional engineering labels, telemetry, buttons, and system metadata.

Headings emphasize ultra-tight letter tracking, heavy weights, and compressed line-heights, evoking structural block typography seen in brutalist hardware manuals. All display titles, sub-claims, buttons, and telemetry tags are typeset in pure uppercase. Monospaced elements utilize expanded tracking (`0.18em` to `0.26em`) to guarantee legibility at sub-pixel sizes, mimicking digital LCD and laser-etched hardware plates. Reading line lengths must be strictly capped between 32ch and 38ch for lead editorial copy.

## Layout & Spacing

The layout model is governed by a rigorous technical grid, spanning up to a maximum container boundary of 1680px. Section boundaries, data cards, and metric arrays must align strictly to structured row and column matrices. 

- **Desktop (1024px+)**: 12-column layout with 2rem (32px) gutters and fluid outer margin scaling up to 4.75rem (76px). Multi-column technical readouts, split specification cards, and asymmetric hardware visualization bays.
- **Tablet (768px - 1023px)**: 8-column layout with 1.5rem (24px) gutters and 2.5rem (40px) outer margin. Secondary cards fold into stacked two-column pairings.
- **Mobile (< 768px)**: 4-column layout with 1rem (16px) gutters and 1.25rem (20px) outer margins. Layout strips complex multi-column grids down to continuous vertical hardware telemetry feeds, maintaining hairline divider rows between items.

Vertical rhythmic spacing between sections remains expansive (80px to 180px), creating a stark museum-grade atmosphere that frames high-density component clusters.

## Elevation & Depth

Visual hierarchy rejects organic drop shadows in favor of tonal surface tiers, precision milled hairlines, and luminous phosphor glows.

1. **Base Floor (`#050507`)**: The global viewport canvas, non-reflective and absolute.
2. **Sub-Panels (`#0B0B10`)**: Flush or recessed content compartments, defined not by shadow, but by `1px solid rgba(245, 243, 238, 0.055)`.
3. **Floating Instrumentation Panels (`rgba(9, 9, 14, 0.78)`)**: Elevated data readouts and inspection HUD cards utilizing a heavy hardware blur (`backdrop-filter: blur(18px)`), framed by `1px solid rgba(245, 243, 238, 0.10)`.
4. **Active/Focus Phosphor Emissions**: Active triggers and interactive states project localized specular violet energy using `box-shadow: 0 0 24px rgba(124, 60, 255, 0.22)`.
5. **Legibility Vignettes**: Large numerical displays sitting atop 3D viewports or ambient lighting must utilize localized high-spread text shadows (`0 4px 60px rgba(5, 5, 7, 0.85)`) to maintain surgical legibility.

## Shapes

The geometric architecture relies on sharp, mechanical precision (level `0`). Core structural elements—spec cards, input panels, data rows, and containers—feature crisp, unrounded 90-degree corners, reflecting machined aluminum enclosures and laboratory instrumentation.

Where tactical ergonomics require tactile micro-radii (such as physical button caps or segmented switches), a razor-thin `2px` to `3px` corner radius is selectively permitted. True pill silhouettes (`999px`) are strictly reserved for isolated operational status badges, floating indicator toasts, and finish selector dots.

## Components

### Buttons & Interactive Controls
- **Solid Button (`.btn--solid`)**: The primary call-to-action. Features an electric purple gradient fill (`linear-gradient(135deg, #7C3CFF 0%, #9B4DFF 100%)`), 2px micro-rounded corners, and white uppercase `label-md` monospaced text with `0.20em` tracking. Padding: `16px 26px`.
- **Outline Button (`.btn--line`)**: Structural secondary action. Transparent background framed by a hairline `1px solid rgba(245, 243, 238, 0.10)` border. Color: `#F5F3EE`. On hover, the border shifts to `rgba(124, 60, 255, 0.76)` accompanied by a subtle internal violet aura.
- **Micro / Navigation Capsule**: Capsule pill (`rounded: 999px`) with frosted glass background (`rgba(16, 16, 23, 0.60)`), hairline border, and monospaced micro-label.

### Badges & Telemetry Tags
- **Micro-Badges (`.tag`, `.eyebrow`)**: Compact rectangular tags, zero corner radius or subtle 2px radius, styled with `#63626C` text in `label-sm` or `caption-micro`. Prefixed with electric violet dots (`#A855F7`) for live status indicators (e.g., `● REC`, `SYS.RDY`).

### Input Fields & Selectors
- **Tactile Input**: Machined rectangular fields with `#0B0B10` background and `1px solid rgba(245, 243, 238, 0.10)`. Monospaced text input (`#F5F3EE`) with uppercase placeholder text in `#63626C`. Focus states feature a crisp `1.5px solid #A855F7` with zero blur offset.
- **Segmented / Hardware Swatches**: Circular mechanical pins (`50%` radius) featuring hard-shell matte finishes (`#121317`, `#D7D4CD`, `#8C72A8`, `#657B69`). Selected state is denoted by a detached coaxial outer ring (`1px solid #A855F7` with `3px` gap).

### Selection Controls (Checkboxes & Radios)
- **Checkboxes**: Pure square (0px radius), `14px × 14px`, `#0B0B10` fill with a `1px solid rgba(245, 243, 238, 0.20)` border. When active, displays a solid `#7C3CFF` fill with a crisp inverted hairline checkmark.
- **Radio Buttons**: Coaxial square-in-square or razor-thin circular ring with a centered active phosphor pip.

### Data Lists & Spec Cards
- **Telemetry Readout Row**: Divided by hairline rules (`rgba(245, 243, 238, 0.055)`). Monospaced metric key on the left in `#63626C` (`label-sm`), right-aligned high-contrast value in `#F5F3EE` (`body-sm` or `label-md` with tabular numbers).
- **HUD Inspection Card**: Frosted floating panel (`rgba(9, 9, 14, 0.78)` with `backdrop-filter: blur(18px)`), bounded by hairline border. Padding: `20px 22px`. Features a top status header, telemetry body, and mechanical micro-button footer.